2 Online stores will be webscraped: Amway and Hivebrands

In order to visualize the website, home.php should be opened.
There are a total of 3 pages, home.php, comparison.php, and checkout.php
Each php page has its respective css file.

Mechanics:
User goes to home.php to visualize the 50 items.
User can click on any of those products.
User will be headed towards comparison.php, where user will see how their product compares to the other brand's product.
User can select "Buy Now" on the comparison.php page.
User will be headed towards checkout.php, where user will input their credentials.
User will click "Buy Now" to process the payment and addOrder.php will be executed automatically.
addOrder.php will handle inputing the transaction data into the ORDERS table.
If everything works fine, user will be redirected to the home.php page.
Now user can keep exploring the products.
Else an error message will be displayed.


4 folders are contained in this file:
"AmwayProducts" and "HivebrandsProducts" show all 50 downloaded html pages.
The "images" folder is used for the display of images in the home.php page.
For visualization/reference purposes:
User can open the folder "DisplayWebsitePictures" to see how the website would be displayed.
